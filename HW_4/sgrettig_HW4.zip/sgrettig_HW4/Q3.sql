-- Author: Samuel Rettig

CREATE INDEX tweet_2
ON tweets (post_month);

CREATE INDEX user_2
ON users (state);

CREATE INDEX hashtag_2
ON hashtags (name);


 -- Above is my create statements for ID 7 
 

CREATE INDEX tweet_2
ON tweets (post_month);

CREATE INDEX user_2
ON users (subcategory);

CREATE INDEX hashtag_2
ON hashtags (name);


  -- Above is my create statements for ID 23
 
 




